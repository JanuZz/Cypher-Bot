module.exports = [
    name: 'ping',
    description: "Pings the bot",
    execute(client, message, args){
        message.channel.send("Pong!")
    }
]